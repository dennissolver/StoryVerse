export default function Page() {
  return <div>It works</div>;
}
