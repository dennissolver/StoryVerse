export default function Page() {
  return (
    <div>
      <h1>Give a StoryVerse Gift</h1>
      <p>
        Purchase a gift and share the joy of personalised storytelling.
      </p>
    </div>
  );
}
