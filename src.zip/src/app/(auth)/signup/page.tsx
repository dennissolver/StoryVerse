import { SignupForm } from '@/components/auth/signup-form';

export const metadata = { title: 'Sign Up - StoryVerse' };

export default function SignupPage() {
  return <SignupForm />;
}
